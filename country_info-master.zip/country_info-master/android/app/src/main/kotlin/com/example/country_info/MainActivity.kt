package com.example.country_info

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
